import{j as r}from"./index-cc1db307.js";import{A as t}from"./AdminProductForm-fc693ef3.js";import"./upload-d95114dd.js";import"./image-plus-16b79066.js";const d=()=>r.jsx(t,{});export{d as default};
