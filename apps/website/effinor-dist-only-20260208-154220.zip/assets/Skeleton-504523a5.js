import{j as t,aM as a}from"./index-cc1db307.js";const n=({className:e,...s})=>t.jsx("div",{className:a("enterprise-skeleton animate-pulse bg-gray-200",e),...s});export{n as S};
