import{j as r}from"./index-cc1db307.js";import{A as o}from"./AdminProductForm-fc693ef3.js";import"./upload-d95114dd.js";import"./image-plus-16b79066.js";const p=()=>r.jsx(o,{});export{p as default};
