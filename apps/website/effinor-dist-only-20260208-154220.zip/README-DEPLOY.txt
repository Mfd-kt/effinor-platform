==========================================
INSTRUCTIONS DE DÉPLOIEMENT
==========================================

IMPORTANT : Ce ZIP contient UNIQUEMENT les fichiers à déployer.

ÉTAPES :

1. Décompressez ce fichier ZIP
2. Sélectionnez TOUS les fichiers et dossiers
3. Uploadez-les DIRECTEMENT dans public_html/
   (pas dans un sous-dossier !)

STRUCTURE ATTENDUE SUR LE SERVEUR :

public_html/
├── index.html
├── .htaccess
├── favicon.svg
├── assets/
│   ├── index-*.js
│   └── index-*.css
└── images/

⚠️  NE PAS créer de sous-dossier !
⚠️  Les fichiers doivent être à la RACINE de public_html/

VÉRIFICATION :

- index.html doit faire environ 4-5 KiB
- .htaccess doit être présent
- Le dossier assets/ doit contenir les fichiers JS et CSS
- Le site doit s'afficher correctement

==========================================
